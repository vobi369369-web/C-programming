#include <stdio.h>

struct Rect {
    int x1;
    int y1;
    int x2;
    int y2;
};

int main() {
    struct Rect r1, r2, bound;

    scanf("%d %d %d %d", &r1.x1, &r1.y1, &r1.x2, &r1.y2);
    scanf("%d %d %d %d", &r2.x1, &r2.y1, &r2.x2, &r2.y2);

    bound.x1 = (r1.x1 < r2.x1) ? r1.x1 : r2.x1;
    bound.y1 = (r1.y1 < r2.y1) ? r1.y1 : r2.y1;
    bound.x2 = (r1.x2 > r2.x2) ? r1.x2 : r2.x2;
    bound.y2 = (r1.y2 > r2.y2) ? r1.y2 : r2.y2;

    printf("%d %d %d %d\n", bound.x1, bound.y1, bound.x2, bound.y2);

    return 0;
}