#include <stdio.h>
#include <string.h>

struct Info {
    char name[101];
    char tel[101];
    char addr[101];
};

int main() {
    struct Info p[3];

    for (int i = 0; i < 3; i++) {
        scanf("%100s %100s %100s", p[i].name, p[i].tel, p[i].addr);
    }

    int minIdx = 0;
    for (int i = 1; i < 3; i++) {
        if (strcmp(p[i].name, p[minIdx].name) < 0) {
            minIdx = i;
        }
    }

    printf("name : %s\n", p[minIdx].name);
    printf("tel : %s\n", p[minIdx].tel);
    printf("addr : %s\n", p[minIdx].addr);

    return 0;
}