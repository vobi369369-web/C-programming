#include <stdio.h>

struct Person { 
    char name[100];
    int age;
};

int main() {
    struct Person me = {"보로비", 18}; 
    struct Person friend;

    scanf("%99s %d", friend.name, &friend.age); 

    printf("Your name: %s, age: %d\n", me.name, me.age);
    printf("Friend's name: %s, age: %d\n", friend.name, friend.age);

    return 0;
}