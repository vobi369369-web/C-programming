#include <stdio.h>

struct SchoolInfo { 
    char school[100];
    int grade;
};

int main() {
    struct SchoolInfo fixed = {"Jejuelementary", 6}; // Khởi tạo sẵn trường và khối theo đề
    struct SchoolInfo input;

    scanf("%99s %d", input.school, &input.grade); // Nhập trường và khối mới cách nhau bởi khoảng trắng

    printf("%d grade in %s School\n", fixed.grade, fixed.school);
    printf("%d grade in %s School\n", input.grade, input.school);

    return 0;
}