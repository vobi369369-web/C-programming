#include <stdio.h>

struct 사람 { // Định nghĩa struct lưu thông tin tên và tuổi
    char 이름[100];
    int 나이;
};

int main() {
    struct 사람 p;

    scanf("%99s", p.이름); // Đọc chuỗi tên (tối đa 99 ký tự, bỏ qua khoảng trắng/xuống dòng đầu)
    scanf("%d", &p.나이); // Đọc số nguyên tuổi

    printf("Your name is %s and you are %d years old.\n", p.이름, p.나이);

    return 0;
}