#include <stdio.h>

struct Info {
    char name[101];
    char tel[101];
    char addr[101];
};

int main() {
    struct Info p;

    scanf("%100s %100s %100s", p.name, p.tel, p.addr);

    printf("name : %s\n", p.name);
    printf("tel : %s\n", p.tel);
    printf("addr : %s\n", p.addr);

    return 0;
}