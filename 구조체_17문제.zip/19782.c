#include <stdio.h>

struct Person {
    char name[100];
    int height;
};

int main() {
    struct Person people[5];

    for (int i = 0; i < 5; i++) {
        scanf("%99s %d", people[i].name, &people[i].height);
    }

    int minIdx = 0;
    for (int i = 1; i < 5; i++) {
        if (people[i].height < people[minIdx].height) {
            minIdx = i;
        }
    }

    printf("%s %d\n", people[minIdx].name, people[minIdx].height);

    return 0;
}