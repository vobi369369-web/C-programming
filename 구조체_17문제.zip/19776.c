#include <stdio.h>

struct Student { // Định nghĩa struct lưu thông tin sinh viên/học sinh
    char name[21];
    char school[21];
    int grade;
};

int main() {
    struct Student s;

    scanf("%20s %20s %d", s.name, s.school, &s.grade); // Đọc 3 giá trị cách nhau bởi khoảng trắng[cite: 6]

    printf("Name : %s\n", s.name);
    printf("School : %s\n", s.school);
    printf("Grade : %d\n", s.grade);

    return 0;
}