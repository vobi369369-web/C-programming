#include <stdio.h>

struct Student {
    char name[100];
    int kor;
    int eng;
};

struct Student plus(struct Student a, struct Student b) {
    struct Student sum = {"Total", a.kor + b.kor, a.eng + b.eng};
    return sum;
}

int main() {
    struct Student s1, s2;

    scanf("%99s %d %d", s1.name, &s1.kor, &s1.eng);
    scanf("%99s %d %d", s2.name, &s2.kor, &s2.eng);

    struct Student total = plus(s1, s2);

    printf("%s %d %d\n", s1.name, s1.kor, s1.eng);
    printf("%s %d %d\n", s2.name, s2.kor, s2.eng);
    printf("%s %d %d\n", total.name, total.kor, total.eng);

    return 0;
}