#include <stdio.h>

struct Student {
    char name[100];
    int score;
};

int main() {
    struct Student students[5];

    for (int i = 0; i < 5; i++) {
        scanf("%99s %d", students[i].name, &students[i].score);
    }

    int maxIdx = 0;
    for (int i = 1; i < 5; i++) {
        if (students[i].score > students[maxIdx].score) {
            maxIdx = i;
        }
    }

    printf("%s %d\n", students[maxIdx].name, students[maxIdx].score);

    return 0;
}