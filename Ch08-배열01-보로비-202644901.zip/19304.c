#include <stdio.h>

int main(void) {
    // Khai báo mảng ký tự có kích thước 10 để lưu 10 ký tự
    char arr[10];
    int i;

    // Vòng lặp nhập 10 ký tự từ bàn phím vào mảng (dùng dấu cách trước %c để bỏ qua khoảng trắng/xuống dòng thừa)
    for (i = 0; i < 10; i++) {
        scanf(" %c", &arr[i]);
    }

    // Vòng lặp in các ký tự ngược lại từ phần tử cuối cùng (index 9) về phần tử đầu tiên (index 0)
    for (i = 9; i >= 0; i--) {
        printf("%c ", arr[i]);
    }

    return 0;
}