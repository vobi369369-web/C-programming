#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có sức chứa tối đa 100 phần tử và biến đếm số lượng
    int arr[100];
    int count = 0;
    int input;
    int i;

    // Vòng lặp nhận các số nguyên cho đến khi nhập số 0 hoặc đủ 100 số
    while (count < 100) {
        scanf("%d", &input);
        // Nếu gặp số 0 thì dừng việc nhận dữ liệu
        if (input == 0) {
            break;
        }
        arr[count] = input;
        count++;
    }

    // Vòng lặp in các số từ phần tử cuối cùng vừa nhập ngược về phần tử đầu tiên
    for (i = count - 1; i >= 0; i--) {
        printf("%d ", arr[i]);
    }

    return 0;
}