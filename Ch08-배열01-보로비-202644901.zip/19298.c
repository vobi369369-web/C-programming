#include <stdio.h>

int main(void) {
    // Khai báo biến n để lưu số lượng phần tử và mảng chứa tối đa 100 số nguyên
    int n;
    int arr[100];
    int i;
    int max;

    // Nhập số lượng phần tử n (n <= 100)
    scanf("%d", &n);

    // Vòng lặp nhập n số tự nhiên vào mảng
    for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // Giả định phần tử đầu tiên (arr[0]) là số lớn nhất ban đầu
    max = arr[0];

    // Vòng lặp duyệt qua mảng để tìm số lớn nhất
    for (i = 1; i < n; i++) {
        if (arr[i] > max) {
            max = arr[i]; // Cập nhật lại giá trị lớn nhất nếu tìm thấy số lớn hơn
        }
    }

    // In ra số lớn nhất tìm được
    printf("%d\n", max);

    return 0;
}