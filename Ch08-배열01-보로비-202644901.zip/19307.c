#include <stdio.h>

int main(void) {
    // Khai báo mảng kiểu số thực (double) có kích thước 6 để lưu trọng lượng của 6 người
    double weights[6];
    int i;
    double sum = 0.0;
    double avg;

    // Vòng lặp nhập trọng lượng của 6 người vào mảng từ bàn phím và cộng dồn vào tổng sum
    for (i = 0; i < 6; i++) {
        scanf("%lf", &weights[i]);
        sum += weights[i];
    }

    // Tính trọng lượng trung bình bằng cách chia tổng cho 6.0
    avg = sum / 6.0;

    // In ra kết quả, làm tròn đến chữ số thập phân thứ nhất theo đúng yêu cầu đề bài
    printf("%.1f\n", avg);

    return 0;
}