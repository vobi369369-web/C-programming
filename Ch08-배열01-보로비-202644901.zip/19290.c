#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có kích thước là 5
    int arr[5];
    int i;

    // Vòng lặp thứ nhất: Nhập 5 số nguyên vào mảng
    for (i = 0; i < 5; i++) {
        scanf("%d", &arr[i]);
    }

    // Vòng lặp thứ hai: In ra 5 số nguyên từ mảng
    for (i = 0; i < 5; i++) {
        printf("%d ", arr[i]);
    }

    return 0;
}