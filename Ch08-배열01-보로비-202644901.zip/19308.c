#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên tối đa 100 phần tử và biến đếm số lượng
    int arr[100];
    int count = 0;
    int input;
    int i;
    int max, min;

    // Vòng lặp nhận các số nguyên liên tiếp cho đến khi gặp số 0 hoặc đủ 100 số
    while (count < 100) {
        scanf("%d", &input);
        // Nếu nhập vào số 0 thì dừng việc nhận dữ liệu
        if (input == 0) {
            break;
        }
        arr[count] = input;
        count++;
    }

    // Nếu có dữ liệu được nhập vào mảng
    if (count > 0) {
        // Gán phần tử đầu tiên làm max và min ban đầu
        max = arr[0];
        min = arr[0];

        // Duyệt qua mảng để tìm giá trị lớn nhất và nhỏ nhất
        for (i = 1; i < count; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
            if (arr[i] < min) {
                min = arr[i];
            }
        }

        // In ra tổng của giá trị lớn nhất và nhỏ nhất (max + min)
        printf("%d\n", max + min);
    }

    return 0;
}