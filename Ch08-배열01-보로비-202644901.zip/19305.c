#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có kích thước 5 để lưu 5 số
    int arr[5];
    int i;
    int sum = 0; // Biến lưu tổng các số ở vị trí thứ 1, 3, 5

    // Vòng lặp nhập 5 số nguyên vào mảng từ bàn phím
    for (i = 0; i < 5; i++) {
        scanf("%d", &arr[i]);
    }

    // Tính tổng các số ở vị trí thứ 1, 3 và 5 (tương ứng với index 0, 2 và 4 trong mảng)
    for (i = 0; i < 5; i += 2) {
        sum += arr[i];
    }

    // In ra tổng vừa tính được
    printf("%d\n", sum);

    return 0;
}