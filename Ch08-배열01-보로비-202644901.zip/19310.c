#include <stdio.h>

int main(void) {
    // Khai báo mảng tối đa 100 phần tử và biến đếm số lượng
    int arr[100];
    int count = 0;
    int input;
    int i;

    // Vòng lặp nhận các số nguyên liên tiếp cho đến khi gặp số 0 hoặc đủ 100 số
    while (count < 100) {
        scanf("%d", &input);
        // Nếu nhập vào số 0 thì dừng việc nhận dữ liệu
        if (input == 0) {
            break;
        }
        arr[count] = input;
        count++;
    }

    // In ra số lượng các số đã nhập (không tính số 0)
    printf("%d\n", count);

    // Duyệt qua mảng để biến đổi và in ra các giá trị
    for (i = 0; i < count; i++) {
        if (arr[i] % 2 != 0) {
            // Nếu là số lẻ, nhân đôi giá trị lên (nhân 2)
            printf("%d ", arr[i] * 2);
        } else {
            // Nếu là số chẵn, chia cho 2 (lấy phần nguyên)
            printf("%d ", arr[i] / 2);
        }
    }
    printf("\n");

    return 0;
}