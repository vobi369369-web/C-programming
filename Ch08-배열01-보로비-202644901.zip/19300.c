#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có kích thước 10 để lưu 10 số
    int arr[10];
    int i;
    int max, min;

    // Vòng lặp nhập 10 số nguyên từ bàn phím vào mảng
    for (i = 0; i < 10; i++) {
        scanf("%d", &arr[i]);
    }

    // Gán phần tử đầu tiên (arr[0]) làm giá trị lớn nhất và nhỏ nhất ban đầu
    max = arr[0];
    min = arr[0];

    // Vòng lặp duyệt qua mảng từ phần tử thứ 2 (index 1) để tìm max và min
    for (i = 1; i < 10; i++) {
        // Nếu tìm thấy số lớn hơn max hiện tại, cập nhật lại max
        if (arr[i] > max) {
            max = arr[i];
        }
        // Nếu tìm thấy số nhỏ hơn min hiện tại, cập nhật lại min
        if (arr[i] < min) {
            min = arr[i];
        }
    }

    // In ra số lớn nhất và số nhỏ nhất, cách nhau bằng một khoảng trắng
    printf("%d %d\n", max, min);

    return 0;
}