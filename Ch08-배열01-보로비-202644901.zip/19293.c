#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có kích thước 10 để chứa 10 số
    int arr[10];
    int i;

    // Vòng lặp thứ nhất: Gán các giá trị từ 1 đến 10 vào các phần tử của mảng
    // Phần tử arr[0] gán bằng 1, arr[1] gán bằng 2, ..., arr[9] gán bằng 10
    for (i = 0; i < 10; i++) {
        arr[i] = i + 1;
    }

    // Vòng lặp thứ hai: In các giá trị trong mảng ra màn hình, mỗi số cách nhau một khoảng trắng
    for (i = 0; i < 10; i++) {
        printf("%d ", arr[i]);
    }

    return 0;
}