#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có kích thước 10 để lưu 10 số
    int arr[10];
    int i;
    int sum_odd = 0;   // Biến lưu tổng các số ở vị trí lẻ (thứ 1, 3, 5, 7, 9)
    int sum_even = 0;  // Biến lưu tổng các số ở vị trí chẵn (thứ 2, 4, 6, 8, 10)

    // Vòng lặp nhập 10 số nguyên vào mảng từ bàn phím
    for (i = 0; i < 10; i++) {
        scanf("%d", &arr[i]);
    }

    // Duyệt qua mảng để phân loại và cộng dồn tổng vị trí lẻ / chẵn
    for (i = 0; i < 10; i++) {
        // Kiểm tra thứ tự vị trí (tính từ 1: i + 1)
        if ((i + 1) % 2 != 0) {
            // Vị trí lẻ (index 0, 2, 4, 6, 8 tương ứng số thứ 1, 3, 5, 7, 9)
            sum_odd += arr[i];
        } else {
            // Vị trí chẵn (index 1, 3, 5, 7, 9 tương ứng số thứ 2, 4, 6, 8, 10)
            sum_even += arr[i];
        }
    }

    // In kết quả ra màn hình theo đúng định dạng mẫu của đề bài
    printf("odd : %d\n", sum_odd);
    printf("even : %d\n", sum_even);

    return 0;
}