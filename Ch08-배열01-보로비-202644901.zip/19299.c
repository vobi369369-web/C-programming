#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có kích thước 10 để lưu 10 số
    int arr[10];
    int i;
    int min;

    // Vòng lặp nhập 10 số nguyên từ bàn phím vào mảng
    for (i = 0; i < 10; i++) {
        scanf("%d", &arr[i]);
    }

    // Giả định phần tử đầu tiên (arr[0]) là số nhỏ nhất ban đầu
    min = arr[0];

    // Vòng lặp duyệt qua mảng từ phần tử thứ 2 (index 1) để tìm số nhỏ nhất
    for (i = 1; i < 10; i++) {
        if (arr[i] < min) {
            min = arr[i]; // Cập nhật lại giá trị nhỏ nhất nếu tìm thấy số nhỏ hơn
        }
    }

    // In ra số nhỏ nhất tìm được
    printf("%d\n", min);

    return 0;
}