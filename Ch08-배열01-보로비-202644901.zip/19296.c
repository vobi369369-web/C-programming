#include <stdio.h>

int main(void) {
    // Khai báo mảng lưu số ngày của 12 tháng (index từ 0 đến 11, trong đó tháng 2 để là 28 ngày)
    // Lưu ý: Đặt thêm phần tử giả ở index 0 để dễ tra cứu theo số tháng (tháng 1 tương ứng index 1, ...)
    int days[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int month;

    // Vòng lặp liên tục nhận giá trị tháng từ bàn phím
    while (1) {
        scanf("%d", &month);

        // Nếu tháng nằm ngoài khoảng từ 1 đến 12 thì dừng chương trình
        if (month < 1 || month > 12) {
            break;
        }

        // In ra số ngày tương ứng của tháng đó trên một dòng riêng biệt
        printf("%d\n", days[month]);
    }

    return 0;
}