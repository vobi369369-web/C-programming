#include <stdio.h>

int main(void) {
    // Khai báo một mảng ký tự (char) có kích thước là 10 để lưu 10 chữ cái
    char arr[10];
    int i;

    // Vòng lặp thứ nhất: Nhập 10 ký tự từ bàn phím (lưu ý dùng định dạng %c)
    for (i = 0; i < 10; i++) {
        scanf(" %c", &arr[i]); // Dấu cách trước %c giúp bỏ qua các khoảng trắng/ký tự xuống dòng thừa
    }

    // Vòng lặp thứ hai: In liên tục 10 ký tự vừa nhập ra màn hình (không có khoảng cách giữa các ký tự)
    for (i = 0; i < 10; i++) {
        printf("%c", arr[i]);
    }

    return 0;
}