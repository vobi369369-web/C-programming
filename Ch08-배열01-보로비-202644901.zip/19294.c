#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên tối đa 100 phần tử và biến đếm số lượng phần tử đã nhập
    int arr[100];
    int count = 0;
    int input;
    int i;

    // Vòng lặp nhận các số nguyên liên tiếp cho đến khi nhập vào số 0 hoặc đủ 100 số
    while (count < 100) {
        scanf("%d", &input);
        // Nếu nhập vào số 0 thì dừng việc nhận dữ liệu
        if (input == 0) {
            break;
        }
        arr[count] = input;
        count++;
    }

    // In ra các số ở vị trí chẵn (vị trí thứ 2, 4, 6... tương ứng với index 1, 3, 5... trong mảng)
    // Lưu ý: Đề bài yêu cầu "짝수 번째" (thứ tự chẵn tính từ 1: số thứ 2, 4, 6... tương ứng index 1, 3, 5...)
    for (i = 1; i < count; i += 2) {
        printf("%d ", arr[i]);
    }

    return 0;
}