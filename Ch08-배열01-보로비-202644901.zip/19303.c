#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có kích thước 10 để lưu 10 số
    int arr[10];
    int i;
    int sum_even = 0;    // Tổng các số ở vị trí chẵn (thứ 2, 4, 6, 8, 10)
    int sum_odd = 0;     // Tổng các số ở vị trí lẻ (thứ 1, 3, 5, 7, 9)
    int count_odd = 0;   // Đếm số lượng phần tử ở vị trí lẻ để tính trung bình
    double avg_odd;      // Điểm trung bình của các số ở vị trí lẻ

    // Vòng lặp nhập 10 số nguyên vào mảng
    for (i = 0; i < 10; i++) {
        scanf("%d", &arr[i]);
    }

    // Duyệt qua mảng để tính toán
    for (i = 0; i < 10; i++) {
        // Kiểm tra vị trí thứ tự (vị trí tính từ 1: i + 1)
        if ((i + 1) % 2 == 0) {
            // Vị trí chẵn (thứ 2, 4, 6, 8, 10 tương ứng index 1, 3, 5, 7, 9)
            sum_even += arr[i];
        } else {
            // Vị trí lẻ (thứ 1, 3, 5, 7, 9 tương ứng index 0, 2, 4, 6, 8)
            sum_odd += arr[i];
            count_odd++;
        }
    }

    // Tính trung bình cộng của các giá trị ở vị trí lẻ, làm tròn đến chữ số thập phân thứ nhất
    avg_odd = (double)sum_odd / count_odd;

    // In kết quả theo đúng định dạng yêu cầu của đề bài
    printf("sum : %d\n", sum_even);
    printf("avg : %.1f\n", avg_odd);

    return 0;
}