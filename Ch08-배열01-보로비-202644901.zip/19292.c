#include <stdio.h>

int main(void) {
    // Khai báo mảng ký tự có kích thước 26 để chứa 26 chữ cái tiếng Anh
    char arr[26];
    int i;

    // Vòng lặp thứ nhất: Gán các chữ cái in hoa từ 'A' đến 'Z' vào mảng
    // Mã ASCII của 'A' là 65, ta cộng thêm i (từ 0 đến 25) để được các ký tự tiếp theo
    for (i = 0; i < 26; i++) {
        arr[i] = 'A' + i;
    }

    // Vòng lặp thứ hai: In các ký tự ngược lại từ cuối mảng (index 25) về đầu mảng (index 0)
    for (i = 25; i >= 0; i--) {
        printf("%c ", arr[i]);
    }

    return 0;
}