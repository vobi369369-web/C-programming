#include <stdio.h>

int main(void) {
    // Khởi tạo mảng chứa điểm trung bình của các lớp từ lớp 1 đến lớp 6
    // (Phần tử ở index 0 để giá trị 0.0 để số thứ tự lớp khớp với chỉ số mảng: index 1 là lớp 1, ...)
    double scores[7] = {0.0, 85.6, 79.5, 83.1, 80.0, 78.2, 75.0};
    int class1, class2;
    double sum;

    // Nhập vào số thứ tự của 2 lớp từ bàn phím
    scanf("%d %d", &class1, &class2);

    // Tính tổng điểm trung bình của 2 lớp đã chọn
    sum = scores[class1] + scores[class2];

    // In ra kết quả, lấy đúng 1 chữ số thập phân theo yêu cầu đề bài
    printf("%.1f\n", sum);

    return 0;
}