#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có kích thước 10 để lưu điểm của 10 học sinh
    int scores[10];
    int i;
    int sum = 0;
    double avg;

    // Vòng lặp nhập điểm của 10 học sinh từ bàn phím vào mảng và tính tổng
    for (i = 0; i < 10; i++) {
        scanf("%d", &scores[i]);
        sum += scores[i]; // Cộng dồn điểm vào biến tổng sum
    }

    // Tính điểm trung bình (ép kiểu sum sang double để phép chia trả về số thực)
    avg = (double)sum / 10.0;

    // In ra tổng điểm (sum) và điểm trung bình (avg) theo đúng định dạng mẫu
    printf("sum = %d\n", sum);
    printf("avg = %.1f\n", avg);

    return 0;
}