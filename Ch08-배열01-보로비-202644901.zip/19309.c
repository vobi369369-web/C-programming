#include <stdio.h>

int main(void) {
    // Khai báo mảng tối đa 100 số nguyên và các biến quản lý
    int arr[100];
    int count = 0;
    int input;
    int i;
    int mult_count = 0; // Đếm số lượng bội của 5
    int sum = 0;        // Tổng các bội của 5
    double avg;         // Trung bình các bội của 5

    // Vòng lặp nhận các số nguyên liên tiếp cho đến khi gặp số 0 hoặc đủ 100 số
    while (count < 100) {
        scanf("%d", &input);
        // Nếu nhập vào số 0 thì dừng việc nhận dữ liệu
        if (input == 0) {
            break;
        }
        arr[count] = input;
        count++;
    }

    // Duyệt qua mảng để lọc các số là bội của 5 (chia hết cho 5)
    for (i = 0; i < count; i++) {
        if (arr[i] % 5 == 0) {
            mult_count++;
            sum += arr[i];
        }
    }

    // Tính điểm trung bình (tránh trường hợp chia cho 0 nếu không có số nào là bội của 5)
    if (mult_count > 0) {
        avg = (double)sum / mult_count;
    } else {
        avg = 0.0;
    }

    // In kết quả ra màn hình theo đúng định dạng yêu cầu của đề bài
    printf("Multiples of 5 : %d\n", mult_count);
    printf("sum : %d\n", sum);
    printf("avg : %.1f\n", avg);

    return 0;
}