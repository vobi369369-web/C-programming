//문제 (Đề bài): Viết chương trình nhận vào một số nguyên và in ra kết quả tương ứng dựa theo các khoảng giá trị sau:   
//Từ 90 trở lên: In ra "Excellent"   
//Từ 80 trở lên: In ra "Good"   
//Từ 70 trở lên: In ra "Pass"   
//Các trường hợp còn lại (그 외): In ra "Fail"
#include <stdio.h>

int main() {
    int n;
    
    // Nhận số nguyên từ bàn phím
    scanf("%d", &n);
    
    // Kiểm tra điều kiện và in thông báo tương ứng
    if (n >= 90) {
        printf("Excellent\n");
    } else if (n >= 80) {
        printf("Good\n");
    } else if (n >= 70) {
        printf("Pass\n");
    } else {
        printf("Fail\n");
    }
    
    return 0;
}