//문제 (Đề bài): Viết chương trình nhận vào 3 số nguyên và in ra thông báo tương ứng dựa theo các quy tắc sau:   
//Nếu cả 3 số đều là số dương (> 0): In ra "All Positive"   
//Nếu có ít nhất 1 số bằng 0: In ra "Contain Zero"   
//Trường hợp còn lại (그 외): In ra "Mixed"

#include <stdio.h>

int main() {
    // Khai báo 3 biến để lưu 3 số nguyên nhập vào
    int a, b, c;
    
    // Nhận 3 số nguyên từ bàn phím (cách nhau bởi khoảng trắng)
    scanf("%d %d %d", &a, &b, &c);
    
    // Kiểm tra điều kiện 1: CẢ 3 SỐ ĐỀU LÀ SỐ DƯƠNG (> 0)
    // Dùng toán tử && (Và) vì cả a, b và c đều phải lớn hơn 0
    if (a > 0 && b > 0 && c > 0) {
        printf("All Positive\n");
    }
    // Kiểm tra điều kiện 2: ÍT NHẤT 1 TRONG 3 SỐ BẰNG 0
    // Dùng toán tử || (Hoặc) vì chỉ cần 1 trong 3 số bằng 0 là thỏa mãn
    else if (a == 0 || b == 0 || c == 0) {
        printf("Contain Zero\n");
    }
    // Trường hợp còn lại: Không thỏa mãn 2 điều kiện trên
    // (ví dụ: có số âm và không có số 0 nào)
    else {
        printf("Mixed\n");
    }
    
    return 0;
}