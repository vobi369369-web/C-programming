//문제 (Đề bài): Viết chương trình liên tục nhận vào các số nguyên. Khi nhập số 0, chương trình sẽ dừng lại. Hãy tính và in ra: số lượng các số đã nhập (không tính số 0), tổng (sum), và trung bình cộng (avg) của các số đó.
#include <stdio.h>

int main() {
    int n;
    int cnt = 0;   // Biến đếm số lượng các số đã nhập (khởi tạo bằng 0)
    int sum = 0;   // Biến lưu tổng các số (khởi tạo bằng 0)
    double avg = 0.0; // Biến lưu giá trị trung bình (dùng kiểu double để tính số thập phân)
    
    // Dùng vòng lặp while(1) để lặp vô hạn, đến khi nào gặp số 0 thì dùng break để thoát
    while (1) {
        scanf("%d", &n); // Nhận số nguyên từ bàn phím
        
        // Nếu nhập số 0 thì dừng vòng lặp
        if (n == 0) {
            break;
        }
        
        // Cộng dồn vào tổng
        sum += n; 
        
        // Tăng số lượng đếm lên 1
        cnt++; 
    }
    
    // Tính trung bình: chuyển đổi tổng (sum) sang kiểu double để phép chia ra số thập phân chính xác
    if (cnt > 0) {
        avg = (double)sum / cnt;
    }
    
    // In ra kết quả đúng theo định dạng mẫu
    printf("cnt = %d\n", cnt);
    printf("sum = %d\n", sum);
    // Dùng %.2f để in ra số thực với 2 chữ số thập phân sau dấu phẩy
    printf("avg = %.2f\n", avg);
    
    return 0;
}