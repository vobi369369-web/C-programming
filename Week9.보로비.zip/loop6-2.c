//문제 (Đề bài): Viết chương trình hiển thị danh sách các quốc gia, yêu cầu nhập số để in ra thủ đô tương ứng, 
//lặp lại quá trình này cho đến khi nhập một số khác ngoài các lựa chọn thì in ra "none" và kết thúc chương trình.
//Nếu nhập 1: In ra thủ đô "Seoul".   
//Nếu nhập 2: In ra thủ đô "Washington".   
//Nếu nhập 3: In ra thủ đô "Tokyo".   
//Nếu nhập 4: In ra thủ đô "Beijing".   
//Nếu nhập số khác (ngoài khoảng từ 1 đến 4): In ra "none" và kết thúc chương trình.   
#include <stdio.h>

int main() {
    int choice; // Biến lưu lựa chọn của người dùng
    
    // Dùng vòng lặp vô hạn while(1) để liên tục hiển thị menu và nhận giá trị
    while (1) {
        // Hiển thị danh sách quốc gia và dòng yêu cầu nhập số
        printf("1. Korea\n");
        printf("2. USA\n");
        printf("3. Japan\n");
        printf("4. China\n");
        printf("number? ");
        
        // Nhận số nguyên từ bàn phím
        scanf("%d", &choice);
        
        // Kiểm tra lựa chọn tương ứng với từng quốc gia
        if (choice == 1) {
            printf("Seoul\n");
        } 
        else if (choice == 2) {
            printf("Washington\n");
        } 
        else if (choice == 3) {
            printf("Tokyo\n");
        } 
        else if (choice == 4) {
            printf("Beijing\n");
        } 
        else {
            // Nếu nhập số khác ngoài 1, 2, 3, 4 thì in ra "none" rồi thoát khỏi vòng lặp
            printf("none\n");
            break; 
        }
    }
    
    return 0;
}