//문제 (Đề bài): Viết chương trình liên tục nhận vào các số nguyên. 
//Nếu giá trị nhập vào là 0 thì kết thúc việc nhập liệu. 
//Hãy tìm và in ra giá trị lớn nhất (MAX) và nhỏ nhất (MIN) trong số các giá trị nằm trong khoảng từ 1 đến 100.
//(Lưu ý: Các số nằm ngoài phạm vi 1~100 sẽ không được xử lý/tính toán, và chắc chắn sẽ có ít nhất một số hợp lệ trong khoảng 1~100 được nhập vào).
#include <stdio.h>

int main() {
    int n;
    int max = 0;   // Khởi tạo max ban đầu bằng 0 (vì các số hợp lệ đều lớn hơn 0)
    int min = 101; // Khởi tạo min ban đầu bằng 101 (lớn hơn mọi số trong khoảng 1~100)
    
    // Dùng vòng lặp vô hạn while(1) để liên tục nhập số
    while (1) {
        scanf("%d", &n); // Nhận số nguyên từ bàn phím
        
        // Nếu nhập số 0 thì dừng vòng lặp
        if (n == 0) {
            break;
        }
        
        // Chỉ xử lý các số nằm trong khoảng từ 1 đến 100
        if (n >= 1 && n <= 100) {
            // Nếu số hiện tại lớn hơn max thì cập nhật lại max
            if (n > max) {
                max = n;
            }
            // Nếu số hiện tại nhỏ hơn min thì cập nhật lại min
            if (n < min) {
                min = n;
            }
        }
    }
    
    // In ra kết quả đúng theo định dạng mẫu của đề bài
    printf("MAX = %d\n", max);
    printf("MIN = %d\n", min);
    
    return 0;
}