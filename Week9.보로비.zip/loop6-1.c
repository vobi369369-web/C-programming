//문제 (Đề bài): Viết chương trình hiển thị menu lựa chọn, 
//liên tục nhận vào một số nguyên và in ra thông báo tương ứng với số được chọn cho đến khi chọn kết thúc.
//Nếu nhập 1: In ra "You selected Input."
//Nếu nhập 2: In ra "You selected Output."
//Nếu nhập 3: In ra "You selected Delete."
//Nếu nhập 4: In ra "You selected Finish." và kết thúc chương trình.
//Nếu nhập số khác (ngoài khoảng từ 1 đến 4): In ra "Wrong input."
#include <stdio.h>

int main() {
    int choice; // Biến lưu lựa chọn của người dùng
    
    // Dùng vòng lặp vô hạn while(1) để lặp lại việc hiển thị menu và nhận dữ liệu
    while (1) {
        // Hiển thị menu lựa chọn ra màn hình
        printf("1. Input\n");
        printf("2. Output\n");
        printf("3. Delete\n");
        printf("4. Finish\n");
        printf("Enter number: ");
        
        // Nhận số nguyên từ bàn phím
        scanf("%d", &choice);
        
        // Kiểm tra các trường hợp lựa chọn của người dùng
        if (choice == 1) {
            printf("You selected Input.\n");
        } 
        else if (choice == 2) {
            printf("You selected Output.\n");
        } 
        else if (choice == 3) {
            printf("You selected Delete.\n");
        } 
        else if (choice == 4) {
            printf("You selected Finish.\n");
            break; // Thoát khỏi vòng lặp khi người dùng chọn 4 để kết thúc chương trình
        } 
        else {
            // Trường hợp nhập số ngoài khoảng từ 1 đến 4
            printf("Wrong input.\n");
        }
    }
    
    return 0;
}