//문제 (Đề bài): Viết chương trình nhận vào hai số là kết quả của việc tung xúc xắc hai lần, sau đó in ra kết quả dựa theo quy tắc sau:   
//Nếu cả hai số đều từ 4 trở lên (>=4): In ra "WIN."  
//Nếu chỉ có một trong hai số từ 4 trở lên: In ra "DRAW."  
//Nếu cả hai số đều nhỏ hơn 4 (<4): In ra "LOSE."
#include <stdio.h>

int main (){
    //khai báo 2 biến để lưu giá trị của 2 lần tung xúc sắc
    int a, b;
    //nhận 2 giá trị từ bàn phím
    scanf("%d %d", &a ,&b);
    //kiểm tra nếu cả 2 đều >=4 
    if ( a>= 4 && b>= 4 ){
        printf("WIN!\n");
    }
    // hoặc 1 trong 2
    else if ( a>= 4 || b>=4){
        printf("DRAW!\n");
    }
    // còn lại
    else{
        printf("LOSE!\n");
    }
    return 0;
}