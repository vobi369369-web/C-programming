//문제 (Đề bài): Viết chương trình liên tục nhận vào các số nguyên. 
//Nếu số nhập vào không phải là bội số của 3 thì không làm gì cả; nếu là bội số của 3 thì in ra thương số khi chia số đó cho 3 ($n / 3$). 
//Chương trình sẽ lặp lại công việc này và kết thúc khi người dùng nhập vào số -1.
#include <stdio.h>

int main() {
    int n;
    
    // Dùng vòng lặp vô hạn while(1) để liên tục nhận dữ liệu từ bàn phím
    while (1) {
        scanf("%d", &n); // Nhận số nguyên
        
        // Kiểm tra điều kiện dừng: nếu nhập vào số -1 thì thoát khỏi vòng lặp
        if (n == -1) {
            break;
        }
        
        // Kiểm tra xem số vừa nhập có phải là bội số của 3 không (chia hết cho 3, dư 0)
        if (n % 3 == 0) {
            // Nếu là bội số của 3, in ra thương của phép chia cho 3 (n / 3)
            printf("%d\n", n / 3);
        }
        // Nếu không phải bội số của 3, chương trình tự động bỏ qua và tiếp tục vòng lặp mới
    }
    
    return 0;
}