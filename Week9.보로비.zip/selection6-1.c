//문제 (Đề bài): Viết chương trình nhận vào 3 số nguyên và in ra số lớn nhất trong số đó.
#include <stdio.h>

int main() {
    // Khai báo 3 biến lưu 3 số nguyên và 1 biến max để tìm giá trị lớn nhất
    int a, b, c, max;
    
    // Nhận 3 số nguyên từ bàn phím (cách nhau bởi khoảng trắng)
    scanf("%d %d %d", &a, &b, &c);
    
    // Giả sử ban đầu số a là số lớn nhất
    max = a;
    
    // So sánh max với số b, nếu b lớn hơn thì cập nhật lại max là b
    if (b > max) {
        max = b;
    }
    
    // So sánh max tiếp tục với số c, nếu c lớn hơn thì cập nhật lại max là c
    if (c > max) {
        max = c;
    }
    
    // In ra kết quả đúng định dạng của đề bài
    printf("max = %d\n", max);
    
    return 0;
}