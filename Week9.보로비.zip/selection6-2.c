//문제 (Đề bài): Viết chương trình nhận vào một số nguyên và in ra kết quả theo các quy tắc sau:   Nếu giá trị nhập vào là số dương ($> 0$):   
//Nếu là số chẵn: In ra "Even Number"   
//Nếu là số lẻ: In ra "Odd Number"  
//Nếu giá trị nhập vào không phải là số dương (<=0, tức là số âm hoặc bằng 0): In ra "Non positive"   
#include <stdio.h>

int main() {
    // Khai báo biến lưu số nguyên nhập vào
    int n;
    
    // Nhận số nguyên từ bàn phím
    scanf("%d", &n);
    
    // Kiểm tra xem số đó có phải là số dương không (> 0)
    if (n > 0) {
        // Nếu là số dương, tiếp tục kiểm tra xem là số chẵn hay số lẻ
        // Dùng toán tử % (chia lấy dư): nếu chia cho 2 dư 0 thì là số chẵn
        if (n % 2 == 0) {
            printf("Even Number\n");
        } else { // Ngược lại, chia cho 2 dư khác 0 thì là số lẻ
            printf("Odd Number\n");
        }
    } 
    // Trường hợp còn lại: số không phải là số dương (<= 0)
    else {
        printf("Non positive\n");
    }
    
    return 0;
}