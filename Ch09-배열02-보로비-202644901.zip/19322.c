#include <stdio.h>

int main(void) {
    // Khai báo mảng 2 chiều lưu điểm 5 học sinh x 4 môn học
    int scores[5][4];
    int i, j;
    int sum;
    double avg;

    // Vòng lặp nhận điểm 4 môn cho từng học sinh (5 học sinh)
    for (i = 0; i < 5; i++) {
        for (j = 0; j < 4; j++) {
            scanf("%d", &scores[i][j]);
        }
    }

    // Duyệt qua từng học sinh để tính tổng điểm và điểm trung bình
    for (i = 0; i < 5; i++) {
        sum = 0;
        for (j = 0; j < 4; j++) {
            sum += scores[i][j];
        }
        // Tính trung bình (chia cho 4 môn), ép kiểu sang double để lấy phần thập phân
        avg = (double)sum / 4.0;

        // In ra tổng điểm và điểm trung bình (làm tròn đến 1 chữ số thập phân bằng %.1f)
        printf("%d %.1f\n", sum, avg);
    }

    return 0;
}