#include <stdio.h>

int main(void) {
    // Khai báo mảng đếm tần suất cho các mốc điểm từ 0 đến 100 (chia theo bước 10 điểm nên dùng kích thước 11), khởi tạo bằng 0
    int count[11] = {0};
    int score;
    int i;

    // Vòng lặp liên tục nhận điểm số từ bàn phím cho đến khi nhập vào 0
    while (1) {
        scanf("%d", &score);
        
        if (score == 0) {
            break;
        }
        
        // Chia điểm cho 10 để gom nhóm theo mốc hàng chục (ví dụ: 63 -> 6, 100 -> 10)
        int index = score / 10;
        count[index]++;
    }

    // Duyệt từ mốc điểm cao xuống thấp (từ 10 xuống 0, tương ứng điểm từ 100 xuống 0)
    for (i = 10; i >= 0; i--) {
        if (count[i] > 0) {
            // In ra mốc điểm (i * 10) và số lượng học sinh đạt mức điểm đó
            printf("%d : %d\n", i * 10, count[i]);
        }
    }

    return 0;
}