#include <stdio.h>

int main(void) {
    // Khai báo mảng đếm tần suất cho 26 chữ cái tiếng Anh in hoa ('A' đến 'Z'), khởi tạo bằng 0
    int count[26] = {0};
    char ch;
    int i;

    // Vòng lặp liên tục nhận các ký tự từ bàn phím
    while (1) {
        // Dùng dấu cách trước %c để bỏ qua khoảng trắng hoặc xuống dòng thừa
        scanf(" %c", &ch);
        
        // Nếu ký tự nhập vào không nằm trong khoảng chữ cái in hoa ('A' đến 'Z') thì dừng
        if (ch < 'A' || ch > 'Z') {
            break;
        }
        
        // Tăng biến đếm của ký tự tương ứng lên 1 (ví dụ: 'A' tương ứng index 0)
        count[ch - 'A']++;
    }

    // Duyệt qua bảng chữ cái từ 'A' đến 'Z' để in ra các chữ cái xuất hiện ít nhất một lần
    for (i = 0; i < 26; i++) {
        if (count[i] > 0) {
            printf("%c : %d\n", 'A' + i, count[i]);
        }
    }

    return 0;
}