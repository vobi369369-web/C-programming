#include <stdio.h>

int main(void) {
    // Khai báo mảng đếm tần suất xuất hiện cho các số từ 1 đến 10 (khởi tạo tất cả bằng 0)
    int count[11] = {0};
    int input;
    int i;

    // Vòng lặp liên tục nhận các số nguyên từ bàn phím
    while (1) {
        scanf("%d", &input);
        
        // Nếu số nhập vào nằm ngoài khoảng từ 1 đến 10 thì dừng việc nhận dữ liệu
        if (input < 1 || input > 10) {
            break;
        }
        
        // Tăng biến đếm số lần xuất hiện của số đó lên 1
        count[input]++;
    }

    // Duyệt từ 1 đến 10 để in ra các số xuất hiện ít nhất một lần theo thứ tự tăng dần
    for (i = 1; i <= 10; i++) {
        if (count[i] > 0) {
            printf("%d : %d\n", i, count[i]);
        }
    }

    return 0;
}