#include <stdio.h>

int main(void) {
    // Khai báo mảng 2 chiều lưu điểm 3 học sinh x 3 môn (Quốc ngữ, Anh, Toán)
    int scores[3][3];
    int i, j;
    
    // Mảng lưu tổng điểm của từng học sinh (3 học sinh)
    int student_sum[3] = {0};
    
    // Mảng lưu tổng điểm của từng môn học (3 môn: Quốc ngữ, Anh, Toán)
    int subject_sum[3] = {0};
    
    // Tổng điểm của toàn bộ học sinh và tất cả các môn
    int total_sum = 0;

    // Vòng lặp nhập điểm 3 môn cho từng học sinh
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &scores[i][j]);
            // Cộng dồn vào tổng điểm của học sinh thứ i
            student_sum[i] += scores[i][j];
            // Cộng dồn vào tổng điểm của môn học thứ j
            subject_sum[j] += scores[i][j];
            // Cộng dồn vào tổng điểm chung
            total_sum += scores[i][j];
        }
    }

    // In điểm của từng học sinh kèm theo tổng điểm cá nhân (dòng 1 đến 3)
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            printf("%d ", scores[i][j]);
        }
        printf("%d\n", student_sum[i]);
    }

    // In tổng điểm của từng môn và tổng điểm toàn bộ ở dòng thứ 4
    for (j = 0; j < 3; j++) {
        printf("%d ", subject_sum[j]);
    }
    printf("%d\n", total_sum);

    return 0;
}