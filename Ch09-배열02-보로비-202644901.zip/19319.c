#include <stdio.h>

int main(void) {
    // Khai báo và khởi tạo mảng 2 chiều 4 hàng, 3 cột theo đúng các giá trị trong ví dụ đề bài
    int arr[4][3] = {
        {3, 5, 4},
        {2, 6, 7},
        {8, 10, 1},
        {5, 3, 15}
    };
    int i, j;

    // Duyệt qua từng hàng và từng cột để in ra các phần tử
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 3; j++) {
            printf("%d ", arr[i][j]);
        }
        // Xuống dòng sau khi kết thúc mỗi hàng
        printf("\n");
    }

    return 0;
}