#include <stdio.h>

int main(void) {
    // Khai báo mảng đếm tần suất cho 6 mặt của xúc sắc (từ mặt 1 đến mặt 6), khởi tạo tất cả bằng 0
    int count[7] = {0};
    int input;
    int i;

    // Vòng lặp nhận 10 lần gieo xúc sắc từ bàn phím
    for (i = 0; i < 10; i++) {
        scanf("%d", &input);
        // Tăng biến đếm của mặt xúc sắc vừa nhập lên 1
        count[input]++;
    }

    // In ra số lần xuất hiện của từng mặt xúc sắc từ 1 đến 6
    for (i = 1; i <= 6; i++) {
        printf("%d : %d\n", i, count[i]);
    }

    return 0;
}