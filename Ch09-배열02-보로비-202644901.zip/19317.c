#include <stdio.h>

int main(void) {
    // Khởi tạo mảng gồm 5 số nguyên theo yêu cầu đề bài
    int arr[5] = {95, 75, 85, 100, 50};
    int i, j, temp;

    // Sử dụng thuật toán sắp xếp nổi bọt (Bubble Sort) để sắp xếp mảng theo thứ tự tăng dần
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 4 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                // Hoán đổi giá trị nếu phần tử đứng trước lớn hơn phần tử đứng sau
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    // In ra các phần tử của mảng sau khi đã sắp xếp, cách nhau bằng khoảng trắng
    for (i = 0; i < 5; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}