#include <stdio.h>

int main(void) {
    // Khai báo mảng 2 chiều lưu số liệu 4 lớp x 3 học sinh
    int scores[4][3];
    int i, j;
    int class_sum;
    int total_sum = 0;

    // Vòng lặp nhận dữ liệu số lần đá cầu của 3 học sinh cho từng lớp (4 lớp)
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &scores[i][j]);
        }
    }

    // Duyệt qua từng lớp để tính tổng số lần đá cầu của 3 đại diện lớp đó và in ra
    for (i = 0; i < 4; i++) {
        class_sum = 0;
        for (j = 0; j < 3; j++) {
            class_sum += scores[i][j];
        }
        // Cộng dồn vào tổng số của toàn trường
        total_sum += class_sum;
        
        // In ra tổng của từng lớp trên mỗi dòng
        printf("%d\n", class_sum);
    }

    // In ra tổng số lần đá cầu của tất cả các học sinh ở dòng cuối cùng
    printf("%d\n", total_sum);

    return 0;
}