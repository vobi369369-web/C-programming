#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có kích thước 20 để lưu 20 số Fibonacci đầu tiên
    int fib[20];
    int i;

    // Theo định nghĩa, phần tử thứ nhất (index 0) và thứ hai (index 1) bằng 1
    fib[0] = 1;
    fib[1] = 1;

    // Tính các số Fibonacci từ phần tử thứ 3 (index 2) đến phần tử thứ 20 (index 19)
    for (i = 2; i < 20; i++) {
        // Mỗi số bằng tổng của hai số đứng ngay trước nó
        fib[i] = fib[i - 1] + fib[i - 2];
    }

    // In ra 20 số Fibonacci, mỗi số cách nhau một khoảng trắng
    for (i = 0; i < 20; i++) {
        printf("%d ", fib[i]);
    }
    printf("\n");

    return 0;
}