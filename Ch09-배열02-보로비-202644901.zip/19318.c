#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có kích thước 10 để lưu 10 số
    int arr[10];
    int i, j, temp;

    // Vòng lặp nhập 10 số nguyên vào mảng từ bàn phím
    for (i = 0; i < 10; i++) {
        scanf("%d", &arr[i]);
    }

    // Sử dụng thuật toán sắp xếp nổi bọt (Bubble Sort) để sắp xếp mảng theo thứ tự giảm dần (내림차순)
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9 - i; j++) {
            // Nếu phần tử đứng trước nhỏ hơn phần tử đứng sau thì hoán đổi vị trí
            if (arr[j] < arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    // In ra các phần tử của mảng sau khi đã sắp xếp giảm dần, cách nhau bằng khoảng trắng
    for (i = 0; i < 10; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}