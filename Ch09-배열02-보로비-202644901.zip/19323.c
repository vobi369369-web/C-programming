#include <stdio.h>

int main(void) {
    // Khai báo mảng 2 chiều kích thước 5x5 để lưu các giá trị của tam giác Pascal
    int pascal[5][5] = {0};
    int i, j;

    // Quy luật tạo tam giác Pascal theo đề bài:
    // Hàng đầu tiên, phần tử đầu tiên bằng 1
    pascal[0][0] = 1;

    // Xây dựng các giá trị cho mảng 2 chiều từ hàng thứ 2 trở đi
    for (i = 1; i < 5; i++) {
        for (j = 0; j <= i; j++) {
            if (j == 0) {
                // Phần tử đầu mỗi hàng luôn bằng 1
                pascal[i][j] = 1;
            } else {
                // Mỗi phần tử bằng tổng của số ngay phía trên (pascal[i-1][j]) 
                // và số phía trên bên trái (pascal[i-1][j-1])
                pascal[i][j] = pascal[i - 1][j] + pascal[i - 1][j - 1];
            }
        }
    }

    // In ra tam giác Pascal theo đúng định dạng yêu cầu
    for (i = 0; i < 5; i++) {
        for (j = 0; j <= i; j++) {
            printf("%d ", pascal[i][j]);
        }
        printf("\n");
    }

    return 0;
}