#include <stdio.h>

int main(void) {
    int n;
    // Khai báo mảng chứa tối đa 20 phần tử theo giới hạn đề bài
    int scores[20];
    int i, j, temp;

    // Nhập số lượng học sinh n (n <= 20)
    scanf("%d", &n);

    // Nhập điểm số của n học sinh vào mảng
    for (i = 0; i < n; i++) {
        scanf("%d", &scores[i]);
    }

    // Sử dụng thuật toán sắp xếp nổi bọt (Bubble Sort) để sắp xếp điểm theo thứ tự giảm dần (내림차순)
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - 1 - i; j++) {
            if (scores[j] < scores[j + 1]) {
                temp = scores[j];
                scores[j] = scores[j + 1];
                scores[j + 1] = temp;
            }
        }
    }

    // In ra từng điểm số đã sắp xếp giảm dần, mỗi số trên một dòng
    for (i = 0; i < n; i++) {
        printf("%d\n", scores[i]);
    }

    return 0;
}