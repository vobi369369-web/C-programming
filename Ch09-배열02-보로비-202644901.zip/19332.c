#include <stdio.h>

int main(void) {
    int n;
    // Nhập kích thước số hàng của tam giác Pascal (tối đa 10)
    scanf("%d", &n);

    // Khai báo mảng 2 chiều kích thước tối đa 10x10 để lưu tam giác Pascal
    int pascal[10][10] = {0};
    int i, j;

    // Khởi tạo phần tử đầu tiên của hàng 0 bằng 1
    pascal[0][0] = 1;

    // Xây dựng tam giác Pascal từ hàng 1 đến hàng n - 1
    for (i = 1; i < n; i++) {
        for (j = 0; j <= i; j++) {
            if (j == 0) {
                pascal[i][j] = 1; // Phần tử đầu mỗi hàng luôn bằng 1
            } else {
                // Mỗi phần tử bằng tổng của số ngay phía trên và số phía trên bên trái
                pascal[i][j] = pascal[i - 1][j] + pascal[i - 1][j - 1];
            }
        }
    }

    // In ra tam giác Pascal theo thứ tự ngược lại: từ hàng cuối cùng (n - 1) về hàng đầu tiên (0)
    for (i = n - 1; i >= 0; i--) {
        for (j = 0; j <= i; j++) {
            printf("%d ", pascal[i][j]);
        }
        printf("\n");
    }

    return 0;
}