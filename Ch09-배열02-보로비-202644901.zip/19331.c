#include <stdio.h>

int main(void) {
    // Khai báo mảng 2 chiều lưu ma trận 4 hàng 2 cột
    int arr[4][2];
    int i, j;
    int total_sum = 0;

    // Vòng lặp nhận dữ liệu 4 hàng 2 cột từ bàn phím
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 2; j++) {
            scanf("%d", &arr[i][j]);
            total_sum += arr[i][j]; // Cộng dồn tổng toàn bộ
        }
    }

    // 1. In ra trung bình cộng theo hàng ngang (mỗi hàng có 2 cột)
    for (i = 0; i < 4; i++) {
        int row_sum = arr[i][0] + arr[i][1];
        // Chia nguyên (tự động bỏ phần thập phân khi dùng kiểu int)
        printf("%d ", row_sum / 2);
    }
    printf("\n");

    // 2. In ra trung bình cộng theo cột dọc (mỗi cột có 4 hàng)
    for (j = 0; j < 2; j++) {
        int col_sum = 0;
        for (i = 0; i < 4; i++) {
            col_sum += arr[i][j];
        }
        printf("%d ", col_sum / 4);
    }
    printf("\n");

    // 3. In ra trung bình cộng toàn bộ (tổng tất cả 8 phần tử chia cho 8)
    printf("%d\n", total_sum / 8);

    return 0;
}