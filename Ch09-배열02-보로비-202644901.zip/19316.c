#include <stdio.h>

int main(void) {
    // Khai báo mảng lưu dãy số (tối đa 100 phần tử để an toàn)
    int arr[100];
    int n;
    int i = 2; // Bắt đầu từ phần tử thứ 3 (index 2)

    // Đọc số tự nhiên đầu vào (<= 100)
    scanf("%d", &n);

    // Theo đề bài: phần tử thứ nhất là 100, phần tử thứ hai là số nhập vào
    arr[0] = 100;
    arr[1] = n;

    // Vòng lặp tính toán các số tiếp theo: lấy số đứng trước trừ đi số trước nữa
    // Dừng lại khi giá trị tính ra là số âm (< 0)
    while (1) {
        arr[i] = arr[i - 1] - arr[i - 2];
        
        // Nếu số vừa tính ra là số âm, ta vẫn in nó ra rồi dừng vòng lặp
        if (arr[i] < 0) {
            break;
        }
        i++;
    }

    // In ra toàn bộ dãy số từ đầu cho đến số âm vừa tìm được, cách nhau bởi khoảng trắng
    int j;
    for (j = 0; j <= i; j++) {
        printf("%d ", arr[j]);
    }
    printf("\n");

    return 0;
}