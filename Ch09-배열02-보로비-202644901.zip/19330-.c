#include <stdio.h>

int main(void) {
    // Khai báo mảng 2 chiều kích thước 5x5, khởi tạo toàn bộ bằng 0
    int arr[5][5] = {0};
    int i, j;

    // Khởi tạo hàng đầu tiên (hàng 0): cột 1, 3, 5 (tương ứng index 0, 2, 4) bằng 1
    arr[0][0] = 1;
    arr[0][2] = 1;
    arr[0][4] = 1;

    // Tính giá trị cho các hàng từ hàng thứ 2 trở đi (từ index 1 đến 4)
    for (i = 1; i < 5; i++) {
        for (j = 0; j < 5; j++) {
            // Cộng giá trị phía trên bên trái và phía trên bên phải
            // Cần kiểm tra biên để tránh truy cập ngoài mảng
            int left = (j > 0) ? arr[i - 1][j - 1] : 0;
            int right = (j < 4) ? arr[i - 1][j + 1] : 0;
            
            arr[i][j] = left + right;
        }
    }

    // In ra kết quả của mảng 2 chiều, mỗi số cách nhau một khoảng trắng
    for (i = 0; i < 5; i++) {
        for (j = 0; j < 5; j++) {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}