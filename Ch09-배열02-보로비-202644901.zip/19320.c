#include <stdio.h>

int main(void) {
    // Khai báo và khởi tạo mảng 2 chiều 3 hàng, 5 cột theo đúng các giá trị trong ví dụ đề bài
    int arr[3][5] = {
        {5, 8, 10, 6, 4},
        {11, 20, 1, 13, 2},
        {7, 9, 14, 22, 3}
    };
    int i, j;

    // Duyệt qua từng hàng và từng cột để in ra các phần tử
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 5; j++) {
            // Sử dụng định dạng %2d để in mỗi số chiếm đúng độ rộng 2 ký tự (căn lề phải)
            printf("%2d ", arr[i][j]);
        }
        // Xuống dòng sau khi kết thúc mỗi hàng
        printf("\n");
    }

    return 0;
}