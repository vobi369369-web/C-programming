#include <stdio.h>

int main(void) {
    // Khai báo mảng 2 chiều kích thước 5x5 để lưu giá trị theo quy luật đề bài
    int arr[5][5];
    int i, j;

    // Khởi tạo hàng đầu tiên (hàng 0) và cột đầu tiên (cột 0) đều bằng 1
    for (i = 0; i < 5; i++) {
        arr[i][0] = 1; // Cột đầu tiên bằng 1
        arr[0][i] = 1; // Hàng đầu tiên bằng 1
    }

    // Tính giá trị cho các phần tử còn lại từ arr[1][1] đến arr[4][4]
    // Mỗi phần tử bằng tổng của số ngay phía trên (arr[i-1][j]) và số ngay bên trái (arr[i][j-1])[cite: 17]
    for (i = 1; i < 5; i++) {
        for (j = 1; j < 5; j++) {
            arr[i][j] = arr[i - 1][j] + arr[i][j - 1];
        }
    }

    // In ra mảng 2 chiều sau khi đã hoàn thành, mỗi số cách nhau một khoảng trắng
    for (i = 0; i < 5; i++) {
        for (j = 0; j < 5; j++) {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}