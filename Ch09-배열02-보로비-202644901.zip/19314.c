#include <stdio.h>

int main(void) {
    // Khai báo mảng đếm tần suất cho các chữ số hàng chục từ 0 đến 9, khởi tạo bằng 0
    int count[10] = {0};
    int input;
    int i;

    // Vòng lặp liên tục nhận các số nguyên từ bàn phím
    while (1) {
        scanf("%d", &input);
        
        // Nếu nhập vào số 0 thì dừng việc nhận dữ liệu
        if (input == 0) {
            break;
        }
        
        // Lấy chữ số hàng chục (input / 10) và tăng biến đếm tương ứng lên 1
        // (Ví dụ: số từ 1 đến 9 chia cho 10 sẽ ra 0, tương ứng với hàng chục là 0)
        count[input / 10]++;
    }

    // Duyệt qua các chữ số từ 0 đến 9 để in ra những chữ số xuất hiện ít nhất một lần
    for (i = 0; i < 10; i++) {
        if (count[i] > 0) {
            printf("%d : %d\n", i, count[i]);
        }
    }

    return 0;
}