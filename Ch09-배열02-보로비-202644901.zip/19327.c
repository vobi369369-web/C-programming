#include <stdio.h>

int main(void) {
    // Khai báo mảng số nguyên có kích thước 10 để lưu 10 số của dãy
    int arr[10];
    int i;

    // Nhập hai số tự nhiên đầu tiên nhỏ hơn 10 từ bàn phím
    scanf("%d %d", &arr[0], &arr[1]);

    // Tính các phần tử từ vị trí thứ 3 (index 2) đến vị trí thứ 10 (index 9)
    for (i = 2; i < 10; i++) {
        // Mỗi số bằng chữ số hàng đơn vị của tổng hai số đứng ngay trước nó
        arr[i] = (arr[i - 1] + arr[i - 2]) % 10;
    }

    // In ra 10 số của dãy trên một dòng, cách nhau bằng khoảng trắng
    for (i = 0; i < 10; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}