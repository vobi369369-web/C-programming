#include <stdio.h>

int main() {
    FILE* file;
    char str1[150];

    file = fopen("twostring.txt", "r"); // Mở tệp ở chế độ chỉ đọc ("r")
    if (file == NULL) {
        printf("파일을 열 수 없습니다.\n");
        return 1;
    }

    if (fgets(str1, sizeof(str1), file) == NULL) { // Đọc tối đa sizeof(str1)-1 ký tự (hoặc tới '\n'/EOF) vào str1; trả về NULL nếu lỗi/hết tệp
        printf("첫 번째 문자열을 읽는 데 실패했습니다.\n");
        fclose(file); // Đóng tệp trước khi thoát sớm để tránh rò rỉ tài nguyên
        return 1;
    }

    fclose(file);

    printf("twostring.txt 파일에서 문자열 '%s'를 성공적으로 읽었습니다.\n", str1);
    return 0;
}