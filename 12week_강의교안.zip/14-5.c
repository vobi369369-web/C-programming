#include <stdio.h>

int main() {
    FILE* file; // Con trỏ quản lý luồng tệp
    char str1[] = "C language, ";
    char str2[] = "Text File!!!";

    file = fopen("twostring.txt", "w"); // Mở tệp để ghi; có thì ghi đè, chưa có thì tạo mới
    if (file == NULL) { // Kiểm tra mở tệp có bị lỗi không
        printf("파일을 열 수 없습니다.\n");
        return 1;
    }

    fprintf(file, "%s", str1); // Ghi chuỗi str1 vào tệp file (thay vì in ra màn hình)
    fprintf(file, "%s", str2); // Ghi tiếp str2 ngay sau str1 trong cùng tệp

    fclose(file); // Đóng tệp để lưu dữ liệu và giải phóng tài nguyên

    printf("twostring.txt 파일에 문자열 '%s%s'를 성공적으로 썼습니다.\n", str1, str2);
    return 0;
}